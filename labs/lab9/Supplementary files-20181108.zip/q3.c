/*
 * Program for Q3 of Lab 9 of Cmpt214
 */
#include <stdlib.h>
#include <stdio.h>

int some_function_int(int b)
{
    /* stub function */
    return 0;
}

float some_function_float(char d)
{
    /* stub function */
    return 0.0;
}

void some_function_void(float* b)
{
    /* stub function */
}

int main(void)
{
    printf("Done!\n");
    return 0;
}


