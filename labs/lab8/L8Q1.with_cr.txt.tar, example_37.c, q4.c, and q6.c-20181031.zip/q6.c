/*
 * Program for Q6 of Lab 08
 */
#include <stdlib.h>
#include <stdio.h>

int main(void)
{
    int* a;
    int b[10];
    a = malloc();  /* provide the parameters for this function call */
    int sizeof_a = /* complete this line; determine the size, in bytes, of a */;
    int sizeof_b = /* complete this line; determine the size, in bytes, of b */;

    printf("sizeof_a = %d \n", sizeof_a);
    printf("sizeof_b = %d \n", sizeof_b);

    return 0;
}
