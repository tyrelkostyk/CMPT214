/*
 * for Lab 10
 *
 * Author: Marina Schmidt
 */

#ifndef Q3_CALC_H
#define Q3_CALC_H

float add(float x, float y);
float sub(float x, float y);
float mult(float x, float y);
float power(float x, float y);

#endif // Q3_CALC_H
