#!/bin/sh

# a first script

echo "hello world!"
