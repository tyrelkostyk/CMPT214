#!/bin/sh
# invoke this script with a number of command-line arguments

echo program was invoked by \"$0\"
echo there were $# arguments given on the command line
echo arguments are $@
